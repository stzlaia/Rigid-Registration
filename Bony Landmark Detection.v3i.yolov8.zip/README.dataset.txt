# Bony Landmark Detection > 2024-02-14 3:48pm
https://universe.roboflow.com/sizu/bony-landmark-detection

Provided by a Roboflow user
License: CC BY 4.0

